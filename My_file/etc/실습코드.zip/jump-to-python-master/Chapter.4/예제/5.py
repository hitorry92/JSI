# 프롬프트를 띄워서 사용자 입력 받기
number = input('숫자를 입력하세요 : ')
print(number)
