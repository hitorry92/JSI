# 파일 생성하기
f = open('새파일.txt', 'w')
f.close()

# 새파일.txt를 C:/Python 이라는 디렉터리에 저장하고 싶다면
f = open('C:/Python/새파일.txt', 'w')
f.close()
