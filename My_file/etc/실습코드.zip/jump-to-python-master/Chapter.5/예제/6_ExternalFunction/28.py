# sys
# argv_test.py
import sys
print(sys.argv)

# 강제로 스크립트 종료하기
# sys.exit()

# 자신이 만든 모듈 불러와 사용하기
print(sys.path)

# 경로명 추가
# sys.path.append('C:/Python/Mymodules')
