# 클래스의 가장 간단한 예
class Simple :
    pass

a = Simple()

# 클래스 변수
class Service :
    secret = '영구는 배꼽이 두 개다.'

pey = Service()
print(pey.secret) # '영구는 배꼽이 두 개다.'
