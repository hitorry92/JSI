# 새 파일 안에서 이전에 만든 모듈 불러오기
# modtest.py
import mod2
result = mod2.sum(3, 4)
print(result) # 7
