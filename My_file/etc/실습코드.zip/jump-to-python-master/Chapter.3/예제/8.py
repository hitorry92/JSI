# 다양한 for문의 사용
a = [(1, 2), (3, 4), (5, 6)]
for (first, last) in a :
    print(first + last)
