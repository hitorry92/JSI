# While문
# while문의 기본 구조
treeHit = 0
while treeHit < 10 :
    treeHit = treeHit + 1
    print('나무를 %d번 찍었습니다.' % treeHit)
    if treeHit == 10 :
        print('나무 넘어갑니다.')
