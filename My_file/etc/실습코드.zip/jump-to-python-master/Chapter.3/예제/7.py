# for문
# for문의 기본 구조
test_list = ['one', 'two', 'three']
for i in test_list :
    print(i)
