# 자료형의 참과 거짓
a = [1, 2, 3, 4]
while a :
    a.pop()
'''
4
3
2
1
'''

if [] :
    print("True")
else :
    print("False")
# False

if [1, 2, 3] :
    print("True")
else :
    print("False")
# True
