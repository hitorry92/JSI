'''
['Life', 'is', 'too', 'short']라는 리스트를 Life is too short라는
문다열로 만들어 출력해 보자.
'''

a = ['Life', 'is', 'too', 'short']
result = " ".join(a)
print(result) # Life is too short
