# hello.py
print("Hello World")
